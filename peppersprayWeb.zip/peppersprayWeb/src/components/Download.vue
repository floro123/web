﻿<template>
    <v-card max-width="600"
            class="mx-auto">
        <v-card-title>Download game</v-card-title>
        <v-card-text>
            <p>
                Full client and instructions:
            </p>
            <v-layout justify-space-around wrap>
                <v-btn href="https://github.com/peppersprayEzekiel/pepperspray/wiki/Installation" target="_blank" color="primary">
                    GitHub Wiki [EN]
                </v-btn>
                <v-btn href="https://github.com/peppersprayEzekiel/pepperspray/wiki/RU_Installation" target="_blank" color="primary">
                    GitHub Wiki [RU]
                </v-btn>
            </v-layout>
        </v-card-text>
    </v-card>
</template>

<script>
</script>

<style scoped>
</style>